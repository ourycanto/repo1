# Affichage d'un formulaire d'inscription :

print """
<H3>Veuillez vous identifier, SVP :</H3>

<FORM ACTION = "sessionTest2.py">
Votre nom : <INPUT NAME = "nomClient"> <BR> 
Votre pr�nom : <INPUT NAME = "prenomClient"> <BR>
Votre sexe (m/f) : <INPUT NAME = "sexeClient" SIZE ="1"> <BR>
<INPUT TYPE = "submit" VALUE = "OK">
</FORM>"""



