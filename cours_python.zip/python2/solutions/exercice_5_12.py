#! /usr/bin/env python
# -*- coding: Latin-1 -*-

# Affichage des �l�ments d'une liste

# Liste fournie au d�part :
t2 = ['Janvier','F�vrier','Mars','Avril','Mai','Juin',
      'Juillet','Ao�t','Septembre','Octobre','Novembre','D�cembre']

# Affichage :
i = 0
while i < len(t2):
    print t2[i],    
    i = i + 1
