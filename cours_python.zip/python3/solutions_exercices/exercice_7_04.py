#! /usr/bin/env python
# -*- coding:Utf8 -*-

def volBoite(x1, x2, x3):
    "Volume d'une boîte parallélipipédique"
    return x1 * x2 * x3

# test :
print(volBoite(5.2, 7.7, 3.3))
