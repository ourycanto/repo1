#! /usr/bin/env python
# -*- coding: Utf8 -*-

prefixes, suffixe = "JKLMNOP", "ack"

for p in prefixes:
    print(p + suffixe)
